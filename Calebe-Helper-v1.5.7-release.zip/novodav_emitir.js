(() => {
  'use strict';

  // ⬛ Bloco: configuração e estado do módulo.
  const MODULE_ID = 'calebe-helper-emitir-nota';
  const CHECKBOX_ID = 'calebe-helper-emitir-nota-finalizar';
  const PENDING_KEY = 'calebeHelperEmitirNotaPendenteV1';
  const THERMAL_PENDING_KEY = 'calebeHelperImpressaoTermicaPendenteV1';
  const PRINT_TYPE_STORAGE_KEY = 'calebeHelperTipoImpressaoDAV';
  const EMIT_STORAGE_KEY = 'calebeHelperEmitirNotaAutomaticamente';
  const BASELINE_KEY = `${PENDING_KEY}:baseline`;
  const SCAN_INTERVAL_MS = 500;
  const WAIT_NEW_DAV_MS = 45000;
  const WAIT_THERMAL_CONFIRM_MS = 2000;
  const CONFIRMED_CAIXA_RETRY_MS = 2000;
  const WAIT_CAIXA_PAGE_MS = 30000;

  let observedDocs = new WeakSet();
  let observedPrintSelects = new WeakSet();
  let pending = null;
  let thermalPending = null;
  let scanTimer = null;
  let lastSavedBaseline = '';
  let lastConfirmedCaixaAttemptAt = 0;
  let pendingCaixa = null;
  let thermalTitleTimer = null;
  let thermalTitleTarget = null;
  let thermalTitlePopup = null;
  let thermalTitleLoadHandler = null;

  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();

  const THERMAL_WINDOW_NAME = 'calebeHelperThermalPrint';

  function dispatchPageCommand(doc, detail) {
    try {
      const EventCtor = doc.defaultView?.CustomEvent || CustomEvent;
      doc.dispatchEvent(new EventCtor('calebe-helper:command', { detail }));
      return true;
    } catch (error) {
      console.warn('[Calebe Helper] Não foi possível enviar o comando ao contexto da página.', error);
      return false;
    }
  }

  const getTopDocument = () => {
    try { return window.top.document; } catch { return document; }
  };

  function getFrameDocuments(root = getTopDocument(), docs = [], seen = new Set(), depth = 0) {
    if (!root?.documentElement || seen.has(root) || depth > 4) return docs;

    seen.add(root);
    docs.push(root);

    for (const frame of root.querySelectorAll('iframe')) {
      let child = null;
      try { child = frame.contentDocument; } catch { }
      if (child) getFrameDocuments(child, docs, seen, depth + 1);
    }

    return docs;
  }

  function isDavCreationPage(doc) {
    if (!doc?.documentElement) return false;
    const hasProductFields = Boolean(
      doc.getElementById('inlinePrdCodigo') &&
      (doc.getElementById('btnObs') || doc.getElementById('inlinePrdQtd'))
    );
    const path = String(doc.location?.pathname || '');
    return hasProductFields || (/\/dav0[12]\//i.test(path) &&
      Boolean(doc.querySelector('input[id*="cli"], input[name*="cli"]')));
  }

  // ⬛ Bloco: identifica a tela de confirmação do pagamento.
  function isPaymentAttentionPage(doc) {
    if (!doc?.body) return false;

    return /ATENÇÃO AO PAGAMENTO/i.test(
      normalize(doc.body.innerText || doc.body.textContent)
    );
  }

  function collectDavRows(doc) {
    if (!doc?.documentElement) return [];
    return [...doc.querySelectorAll('tr')]
      .filter(row => row.querySelector('button[onclick*="duplicarDav("]'));
  }

  function isDavListPage(doc) {
    if (!doc?.documentElement) return false;
    const heading = [...doc.querySelectorAll('h6')].some(el =>
      /DAV01[\s\S]{0,40}Documento Auxiliar de Venda/i.test(el.textContent || '')
    );
    if (heading) return true;

    // Nas abas novas a listagem pode perder o h6; o botão nativo continua presente.
    return Boolean(doc.getElementById('btnNovoDav')) && collectDavRows(doc).length > 0;
  }

  function extractDavId(row) {
    const formatted = String(row?.textContent || '').match(/\b\d{3}-(\d{5,})\b/);
    if (formatted) return Number(formatted[1]) || null;

    const onclicks = [
      row?.getAttribute?.('onclick'),
      ...[...(row?.querySelectorAll?.('[onclick]') || [])]
        .map(element => element.getAttribute('onclick'))
    ];

    for (const onclick of onclicks) {
      const match = String(onclick || '').match(
        /(?:duplicarDav|abrirDav|selecionarLinha)\s*\(\s*(?:this\s*,\s*)?(\d+)/
      );
      if (match) return Number(match[1]) || null;
    }

    return null;
  }

  function collectDavIds(doc) {
    if (!isDavListPage(doc)) return [];
    return collectDavRows(doc)
      .map(extractDavId)
      .filter(id => Number.isFinite(id) && id > 0);
  }

  function extractDavIdFromUrl(url) {
    try {
      const value = new URL(String(url || '')).searchParams.get('id');
      return value && /^\d+$/.test(value) ? Number(value) : null;
    } catch {
      return null;
    }
  }

  function persistBaseline(ids) {
    const values = [...new Set((ids || []).map(String))];
    if (!values.length) return;

    const serialized = JSON.stringify(values);
    if (serialized === lastSavedBaseline) return;

    try {
      getTopDocument().defaultView.sessionStorage.setItem(BASELINE_KEY, serialized);
      lastSavedBaseline = serialized;
    } catch { }
  }

  function snapshotExistingDavIds() {
    const ids = new Set();
    for (const doc of getFrameDocuments()) {
      for (const id of collectDavIds(doc)) ids.add(String(id));
    }
    return [...ids];
  }

  function createCheckbox(doc, anchor) {
    const wrapper = doc.createElement('div');
    wrapper.className = 'form-check form-check-inline mb-0 me-2 ms-auto flex-shrink-0';
    wrapper.id = MODULE_ID;

    const input = doc.createElement('input');
    input.type = 'checkbox';
    input.className = 'form-check-input';
    input.id = CHECKBOX_ID;
    input.autocomplete = 'off';

    const label = doc.createElement('label');
    label.className = 'form-check-label';
    label.htmlFor = CHECKBOX_ID;
    label.textContent = 'Emitir nota ao finalizar';

    wrapper.append(input, label);
    anchor.insertAdjacentElement('beforebegin', wrapper);
    return input;
  }

  function installCheckbox(doc) {
    if (!isDavCreationPage(doc)) return;
    if (doc.getElementById(CHECKBOX_ID)) return;

    // ⬛ Bloco: localiza a linha principal do cabeçalho.
    const headerRow = doc.querySelector(
      '.d-flex.align-items-center.justify-content-between.mb-3.flex-wrap.gap-2'
    );

    if (!headerRow) return;

    // ⬛ Bloco: localiza o grupo de botões à direita.
    const actionGroup = [...headerRow.children].find(el =>
      el.matches('.d-flex.gap-2') &&
      el.querySelector(
        '#btnObs, #btnFecharDav, #btnDetalhes, #btnVoltar2'
      )
    );

    if (!actionGroup) return;

    // ⬛ Bloco: insere o checkbox imediatamente antes dos botões.
    const input = createCheckbox(doc, actionGroup);

    input.checked = localStorage.getItem(EMIT_STORAGE_KEY) === 'true';
    input.setAttribute('aria-checked', String(input.checked));

    // ⬛ Bloco: salva cada alteração para os próximos DAVs.
    input.addEventListener('change', () => {
      localStorage.setItem(EMIT_STORAGE_KEY, String(input.checked));
      input.setAttribute('aria-checked', String(input.checked));
    });
  }

  // ⬛ Bloco: adiciona a opção de impressão térmica no fechamento do DAV.
  function installThermalOption(doc) {
    if (!isDavCreationPage(doc)) return;
    const select = doc.getElementById('tipoImpressao');
    if (!select || select.querySelector('option[value="3"]')) return;

    const option = doc.createElement('option');
    option.value = '3';
    option.textContent = 'Imprime DAV — Térmica Bobina 80x40';
    const noPrint = select.querySelector('option[value="0"]');
    if (noPrint) select.insertBefore(option, noPrint);
    else select.appendChild(option);
  }

  // ⬛ Bloco: restaura e memoriza a última opção de impressão selecionada.
  function installPrintTypePreference(doc) {
    if (!isDavCreationPage(doc)) return;

    const select = doc.getElementById('tipoImpressao');
    if (!select || observedPrintSelects.has(select)) return;

    let storage;

    try {
      storage = doc.defaultView.localStorage;
    } catch (error) {
      console.warn('[Calebe Helper] Não foi possível acessar a preferência de impressão salva.', error);
      return;
    }

    try {
      const savedValue = storage.getItem(PRINT_TYPE_STORAGE_KEY);

      if (
        savedValue !== null &&
        [...select.options].some(option => option.value === savedValue)
      ) {
        select.value = savedValue;
      }
    } catch (error) {
      console.warn('[Calebe Helper] Não foi possível restaurar a opção de impressão salva.', error);
    }

    select.addEventListener('change', () => {
      try {
        storage.setItem(PRINT_TYPE_STORAGE_KEY, select.value);
      } catch (error) {
        console.warn('[Calebe Helper] Não foi possível salvar a opção de impressão selecionada.', error);
      }
    });

    observedPrintSelects.add(select);
  }

  // ⬛ Bloco: registra a impressão térmica somente na confirmação do pagamento.
  function beginPendingThermalPrint(doc, control) {
    if (!isPaymentAttentionPage(doc)) return;
    if (!isFinalizationControl(control)) return;

    const select = doc.getElementById('tipoImpressao');

    let selectedPrintType = select?.value || '';

    // Recupera a última opção salva caso o seletor não esteja nesta tela.
    if (!selectedPrintType) {
      try {
        selectedPrintType = doc.defaultView.localStorage.getItem(PRINT_TYPE_STORAGE_KEY) || '';
      } catch { }
    }

    if (selectedPrintType !== '3') return;

    const idFromUrl = new URLSearchParams(String(doc.location?.search || '')).get('id');
    const davId = idFromUrl && /^\d+$/.test(idFromUrl) ? Number(idFromUrl) : null;

    const state = {
      createdAt: Date.now(),
      davId,
      baseline: snapshotExistingDavIds(),
      sourceUrl: String(doc.location?.href || '')
    };

    // A janela somente é reservada neste clique, na tela ATENÇÃO AO PAGAMENTO.
    dispatchPageCommand(doc, { action: 'reserve-thermal-print-window' });

    try {
      getTopDocument().defaultView.sessionStorage.setItem(
        THERMAL_PENDING_KEY,
        JSON.stringify(state)
      );

      thermalPending = state;

      console.info(
        '[Calebe Helper] ATENÇÃO AO PAGAMENTO: fechamento solicitado; janela de impressão reservada e aguardando confirmação do servidor por até 2 segundos.'
      );
    } catch (error) {
      console.warn(
        '[Calebe Helper] Não foi possível guardar a impressão térmica pendente.',
        error
      );
    }
  }

  function loadPendingThermalPrint() {
    if (thermalPending) return;
    try {
      const storage = getTopDocument().defaultView.sessionStorage;
      const raw = storage.getItem(THERMAL_PENDING_KEY);
      const state = JSON.parse(raw || 'null');
      if (state?.createdAt && Date.now() - state.createdAt < WAIT_THERMAL_CONFIRM_MS) {
        thermalPending = state;
      } else if (raw) {
        storage.removeItem(THERMAL_PENDING_KEY);
      }
    } catch { }
  }

  function clearPendingThermalPrint() {
    thermalPending = null;
    try { getTopDocument().defaultView.sessionStorage.removeItem(THERMAL_PENDING_KEY); } catch { }
  }

  // ⬛ Bloco: atualiza o título exibido na página térmica gerada pelo SATGO.
  function stopThermalTitlePolling() {
    if (thermalTitleTimer) {
      window.clearInterval(thermalTitleTimer);
      thermalTitleTimer = null;
    }
    if (thermalTitlePopup && thermalTitleLoadHandler) {
      try { thermalTitlePopup.removeEventListener('load', thermalTitleLoadHandler); } catch { }
    }
    thermalTitlePopup = null;
    thermalTitleLoadHandler = null;
    thermalTitleTarget = null;
  }

  function startThermalTitlePolling(davId, ...candidateWindows) {
    const id = Number(davId);
    if (!Number.isFinite(id) || id <= 0) return;

    stopThermalTitlePolling();

    let popup = null;
    for (const win of candidateWindows) {
      try {
        popup = win?.open?.('', THERMAL_WINDOW_NAME) || null;
        if (popup) break;
      } catch { }
    }
    if (!popup) return;

    const expectedTitle = `DAV Nº ${id}`;
    const deadline = Date.now() + 15000;
    let announced = false;
    thermalTitleTarget = id;

    const applyTitle = () => {
      if (thermalTitleTarget !== id) return;

      try {
        if (popup.closed) {
          stopThermalTitlePolling();
          return;
        }
      } catch {
        stopThermalTitlePolling();
        return;
      }

      let docs = [];
      try { docs = getFrameDocuments(popup.document); } catch { return; }

      for (const doc of docs) {
        const title = doc.getElementById('title');
        if (!title) continue;

        const isField = /^(INPUT|TEXTAREA|SELECT)$/.test(title.tagName || '');
        const current = isField ? title.value : title.textContent;

        if (normalize(current) !== expectedTitle) {
          if (isField) title.value = expectedTitle;
          else title.textContent = expectedTitle;

          if (!announced) {
            announced = true;
            console.info(`[Calebe Helper] Título da impressão térmica atualizado para "${expectedTitle}".`);
          }
        }
        return;
      }
    };

    try { popup.addEventListener('load', applyTitle); } catch { }
    thermalTitlePopup = popup;
    thermalTitleLoadHandler = applyTitle;

    applyTitle();
    thermalTitleTimer = window.setInterval(() => {
      if (Date.now() > deadline) {
        stopThermalTitlePolling();
        return;
      }
      applyTitle();
    }, 250);
  }

  // ⬛ Bloco: prepara o módulo nfe001 e executa a impressão nativa após confirmação do servidor.
  function requestThermalPrintAfterClose(sourceDoc, detail = {}) {
    loadPendingThermalPrint();
    if (!thermalPending) return;

    const davId = Number(detail.davId || thermalPending.davId) || null;
    if (!davId) {
      console.error('[Calebe Helper] O SATGO confirmou o fechamento, mas não foi possível identificar o ID do DAV.');
      clearPendingThermalPrint();
      return;
    }

    if (thermalPending.davId && Number(thermalPending.davId) !== davId) return;

    let sourceUrl;
    try { sourceUrl = new URL(thermalPending.sourceUrl); }
    catch {
      console.error('[Calebe Helper] Não foi possível recuperar a origem do DAV para preparar a impressão térmica.');
      clearPendingThermalPrint();
      return;
    }

    const sessionKey = sourceUrl.searchParams.get('chave');
    if (!sessionKey) {
      console.error('[Calebe Helper] Não foi possível recuperar a chave de sessão para preparar a impressão térmica.');
      clearPendingThermalPrint();
      return;
    }

    const host = getTopDocument();
    const frameId = 'calebe-helper-nfe-thermal-frame';
    let frame = host.getElementById(frameId);
    if (!frame) {
      frame = host.createElement('iframe');
      frame.id = frameId;
      frame.title = 'Preparação da impressão térmica';
      frame.setAttribute('aria-hidden', 'true');
      frame.style.cssText = 'position:fixed;width:1px;height:1px;left:-10000px;top:-10000px;border:0;opacity:0;pointer-events:none;';
      host.body.appendChild(frame);
    }

    const requestId = `thermal-${Date.now()}-${davId}`;
    let resultHandled = false;
    let resultTimer = null;

    const handleResult = event => {
      const result = event.detail || {};
      if (result.id !== requestId || resultHandled) return;
      resultHandled = true;
      if (resultTimer) clearTimeout(resultTimer);
      frame.contentDocument?.removeEventListener('calebe-helper:thermal-print-result', handleResult);

      if (result.ok) {
        console.info(`[Calebe Helper] DAV ${davId} fechado com sucesso; função nativa abrirEspelhoDavTermico(${davId}) executada.`);
        clearPendingThermalPrint();
      } else {
        stopThermalTitlePolling();
        console.error('[Calebe Helper] O módulo nfe001 não conseguiu executar a impressão térmica:', result.error || 'erro não informado');
        clearPendingThermalPrint();
      }
    };

    const executeInNfeFrame = () => {
      let nfeDoc;
      try { nfeDoc = frame.contentDocument; } catch { nfeDoc = null; }
      if (!nfeDoc?.documentElement) return;

      nfeDoc.addEventListener('calebe-helper:thermal-print-result', handleResult);
      console.info(`[Calebe Helper] Fechamento do DAV ${davId} confirmado pelo servidor; carregando o módulo nativo de impressão.`);
      startThermalTitlePolling(davId, sourceDoc.defaultView, frame.contentWindow, window);

      if (!dispatchPageCommand(nfeDoc, {
        action: 'print-thermal-dav',
        davId,
        requestId,
        windowName: THERMAL_WINDOW_NAME
      })) {
        nfeDoc.removeEventListener('calebe-helper:thermal-print-result', handleResult);
        stopThermalTitlePolling();
        console.error('[Calebe Helper] Não foi possível enviar a solicitação ao módulo nativo de impressão.');
        clearPendingThermalPrint();
        return;
      }

      resultTimer = window.setTimeout(() => {
        if (resultHandled) return;
        resultHandled = true;
        nfeDoc.removeEventListener('calebe-helper:thermal-print-result', handleResult);
        stopThermalTitlePolling();
        console.error('[Calebe Helper] O módulo nfe001 não respondeu à solicitação de impressão térmica.');
        clearPendingThermalPrint();
      }, 12000);
    };

    // Reutiliza a página nfe001 que contém a função nativa; não depende de ela já estar visível na tela.
    const nfeUrl = new URL('/calweb/modulos/nfe001/nfe001.php', sourceUrl.origin);
    nfeUrl.searchParams.set('chave', sessionKey);
    const desiredUrl = nfeUrl.href;
    let currentUrl = '';
    try { currentUrl = frame.contentWindow.location.href; } catch { }

    if (currentUrl === desiredUrl && frame.contentDocument?.readyState === 'complete') {
      executeInNfeFrame();
    } else {
      frame.onload = executeInNfeFrame;
      frame.src = desiredUrl;
    }
  }

  // ⬛ Bloco: usa a mesma rotina do botão Caixa DAV da listagem, agora com o ID confirmado pelo servidor.
  function openCaixaForDav(davId) {
    const id = Number(davId);
    if (!Number.isFinite(id) || id <= 0) return false;

    if (typeof window.calebeHelperOpenCaixaDav === 'function') {
      try {
        window.calebeHelperOpenCaixaDav(id);
        return true;
      } catch { }
    }

    // Alternativa autônoma para pacotes que não expõem a rotina da dav1.js.
    let link = null;
    for (const doc of getFrameDocuments()) {
      link = doc.querySelector('a[href*="modulos/nfe001/nfe001.php"]');
      if (link) break;
    }
    if (!link) return false;

    pendingCaixa = { davId: id, createdAt: Date.now() };
    link.click();
    return true;
  }

  // ⬛ Bloco: conclui a abertura da Caixa DAV quando a página nfe001 carrega.
  function isNfeCaixaPage(doc) {
    if (!doc?.documentElement) return false;
    if (/\/modulos\/nfe001\/nfe001\.php$/i.test(String(doc.location?.pathname || ''))) return true;
    return Boolean(doc.getElementById('filtAcao')) ||
      Boolean(doc.querySelector('a[onclick*="abrirCaixaDav("]'));
  }

  function installPendingCaixa(doc) {
    if (!pendingCaixa) return;

    if (Date.now() - pendingCaixa.createdAt > WAIT_CAIXA_PAGE_MS) {
      pendingCaixa = null;
      return;
    }

    if (!isNfeCaixaPage(doc)) return;

    const mode = doc.getElementById('filtAcao');
    if (mode && mode.value !== 'emitir') {
      mode.value = 'emitir';
      mode.dispatchEvent(new doc.defaultView.Event('change', { bubbles: true }));
      return;
    }

    const nativeLink = [...doc.querySelectorAll('a[onclick*="abrirCaixaDav("]')].find(link => {
      const match = String(link.getAttribute('onclick') || '').match(/abrirCaixaDav\s*\(\s*(\d+)\s*,\s*1/);
      return match && Number(match[1]) === pendingCaixa.davId;
    });
    if (!nativeLink) return;

    pendingCaixa = null;
    nativeLink.click();
  }

  function confirmPendingEmit(detail = {}) {
    loadPendingState();
    if (!pending) return false;

    const detailDavId = Number(detail.davId) || null;
    const pendingDavId = Number(pending.davId) || null;
    if (pendingDavId && detailDavId && pendingDavId !== detailDavId) return false;

    const davId = detailDavId || pendingDavId;
    if (!davId) return false;

    pending.confirmedDavId = davId;
    savePendingState();

    if (!openCaixaForDav(davId)) {
      console.warn('[Calebe Helper] O DAV foi fechado, mas a Caixa DAV não abriu pela rotina compartilhada; tentando pela listagem.');
      return false;
    }

    clearPendingState();
    console.info(`[Calebe Helper] Fechamento do DAV ${davId} confirmado; Caixa DAV aberta automaticamente.`);
    return true;
  }

  function retryConfirmedCaixa() {
    if (!pending?.confirmedDavId) return;
    if (Date.now() - lastConfirmedCaixaAttemptAt < CONFIRMED_CAIXA_RETRY_MS) return;

    lastConfirmedCaixaAttemptAt = Date.now();
    const davId = Number(pending.confirmedDavId);
    if (!openCaixaForDav(davId)) return;

    clearPendingState();
    console.info(`[Calebe Helper] Fechamento do DAV ${davId} confirmado; Caixa DAV aberta automaticamente.`);
  }

  // ⬛ Bloco: recebe a confirmação real da mesma resposta usada pelo fechamento nativo.
  function onDavCloseConfirmed(doc, event) {
    const detail = event.detail || {};
    if (!detail.ok) return;

    loadPendingThermalPrint();
    if (thermalPending) {
      const sourcePath = (() => {
        try { return new URL(thermalPending.sourceUrl).pathname; }
        catch { return ''; }
      })();
      if (/\/dav0[12]\/dav0[12]_form\.php$/i.test(sourcePath)) {
        requestThermalPrintAfterClose(doc, detail);
      }
    }

    confirmPendingEmit(detail);
  }

  // ⬛ Bloco: remove solicitações que ficaram sem confirmação do servidor.
  function tryOpenThermalPrint() {
    loadPendingThermalPrint();
    if (!thermalPending) return;
    if (Date.now() - thermalPending.createdAt > WAIT_THERMAL_CONFIRM_MS) {
      console.warn('[Calebe Helper] O servidor não confirmou o fechamento do DAV dentro do prazo; a impressão térmica não foi acionada.');
      clearPendingThermalPrint();
    }
  }

  function isFinalizationControl(control) {
    if (!control) return false;
    if (control.id === 'btnNovoDav' || control.matches('.calebe-helper-caixa-dav')) return false;

    const label = normalize([
      control.textContent,
      control.value,
      control.title,
      control.getAttribute('aria-label'),
      control.getAttribute('onclick'),
      control.id,
      control.className
    ].join(' ')).toLowerCase();

    if (/adicionar|incluir item|novo item|produto|observa[cç][aã]o|limpar|cancelar|voltar/.test(label)) return false;
    return /finalizar|concluir|gravar dav|salvar dav|confirmar dav|fechar dav|fechar|emitir dav|salvar|gravar|confirmar/.test(label);
  }

  function savePendingState() {
    try {
      getTopDocument().defaultView.sessionStorage.setItem(PENDING_KEY, JSON.stringify(pending));
    } catch { }
  }

  function clearPendingState() {
    pending = null;
    try { getTopDocument().defaultView.sessionStorage.removeItem(PENDING_KEY); } catch { }
  }

  function loadPendingState() {
    if (pending) return;
    try {
      const raw = getTopDocument().defaultView.sessionStorage.getItem(PENDING_KEY);
      const data = JSON.parse(raw || 'null');
      if (data && data.createdAt && Date.now() - data.createdAt < WAIT_NEW_DAV_MS) pending = data;
      else if (raw) getTopDocument().defaultView.sessionStorage.removeItem(PENDING_KEY);
    } catch { }
  }

  function isEmitPreferenceEnabled(doc) {
    const checkbox = doc.getElementById(CHECKBOX_ID);
    if (checkbox) return checkbox.checked;
    try { return getTopDocument().defaultView.localStorage.getItem(EMIT_STORAGE_KEY) === 'true'; } catch { return false; }
  }

  function beginPendingEmit(doc, control) {
    if (!isFinalizationControl(control)) return;

    if (pending && Date.now() - pending.createdAt > WAIT_NEW_DAV_MS) clearPendingState();

    const checkbox = doc.getElementById(CHECKBOX_ID);

    // Cada nova etapa de finalização renova o prazo (ex.: pagamento demorado).
    if (pending) {
      if (checkbox && !checkbox.checked) {
        clearPendingState();
        return;
      }
      pending.createdAt = Date.now();
      if (!pending.davId) pending.davId = extractDavIdFromUrl(doc.location?.href);
      savePendingState();
      return;
    }

    if (!isEmitPreferenceEnabled(doc)) return;

    const baseline = snapshotExistingDavIds();
    persistBaseline(baseline);

    lastConfirmedCaixaAttemptAt = 0;
    pendingCaixa = null;
    pending = {
      createdAt: Date.now(),
      baseline,
      davId: extractDavIdFromUrl(doc.location?.href),
      confirmedDavId: null,
      sourceUrl: String(doc.location?.href || ''),
      control: normalize(control.textContent || control.value || control.title)
    };
    savePendingState();
    console.info('[Calebe Helper] Emissão automática marcada; aguardando a confirmação do DAV salvo.');
  }

  function tryOpenCaixa(doc) {
    if (!pending) return;

    if (Date.now() - pending.createdAt > WAIT_NEW_DAV_MS) {
      const missingBaseline = !(pending.baseline || []).length && !pending.confirmedDavId;
      console.warn(
        missingBaseline
          ? '[Calebe Helper] Não foi possível localizar o novo DAV dentro do prazo; a listagem de DAVs não estava aberta para registrar a referência inicial.'
          : '[Calebe Helper] Não foi possível localizar o novo DAV dentro do prazo; a Caixa DAV não foi aberta automaticamente.'
      );
      clearPendingState();
      return;
    }

    if (!isDavListPage(doc)) return;

    const baseline = new Set((pending.baseline || []).map(String));
    const confirmedId = Number(pending.confirmedDavId) || null;
    const rows = collectDavRows(doc)
      .map(row => ({ row, id: extractDavId(row), button: row.querySelector('button.calebe-helper-caixa-dav') }))
      .filter(item => Number.isFinite(item.id) && item.id > 0);

    let candidates;
    if (confirmedId) {
      candidates = rows.filter(item => item.id === confirmedId);
    } else {
      // Sem referência inicial não dá para diferenciar o DAV novo dos antigos.
      if (!baseline.size) return;
      candidates = rows.filter(item => !baseline.has(String(item.id)));
    }

    // A dav1.js instala o botão Caixa DAV via MutationObserver. Aguarda até ele aparecer.
    const ready = candidates.find(item => item.button && !item.button.disabled);
    if (!ready) return;

    const id = ready.id;
    clearPendingState();
    console.info(`[Calebe Helper] DAV ${id} identificado; abrindo a mesma Caixa DAV do botão existente.`);
    ready.button.click();
  }

  function onDocumentClick(doc, event) {
    const target = event.target instanceof doc.defaultView.Element ? event.target : null;
    if (!target) return;
    const control = target.closest('button, a, input[type="button"], input[type="submit"]');
    if (!control) return;

    // Guarda a lista atual antes de abrir um DAV novo.
    if (control.id === 'btnNovoDav' || /novo dav/i.test(normalize(control.textContent || control.title))) {
      persistBaseline(snapshotExistingDavIds());
      return;
    }

    // ⬛ Bloco: emissão automática continua vinculada à tela de criação do DAV.
    // A tela ATENÇÃO AO PAGAMENTO também renova o prazo da emissão pendente.
    if (isDavCreationPage(doc) || isPaymentAttentionPage(doc)) {
      beginPendingEmit(doc, control);
    }

    // ⬛ Bloco: impressão térmica somente na tela ATENÇÃO AO PAGAMENTO.
    if (isPaymentAttentionPage(doc)) {
      beginPendingThermalPrint(doc, control);
    }
  }

  function attachDocument(doc) {
    if (!doc?.documentElement || observedDocs.has(doc)) return;
    observedDocs.add(doc);
    doc.addEventListener('click', event => onDocumentClick(doc, event), true);
    doc.addEventListener('calebe-helper:dav-close-confirmed', event => onDavCloseConfirmed(doc, event));

    const observer = new MutationObserver(() => {
      installCheckbox(doc);
      installThermalOption(doc);
      installPrintTypePreference(doc);
      installPendingCaixa(doc);
      tryOpenCaixa(doc);
      tryOpenThermalPrint(doc);
    });
    observer.observe(doc.documentElement, { childList: true, subtree: true });

    installCheckbox(doc);
    installThermalOption(doc);
    installPrintTypePreference(doc);
    installPendingCaixa(doc);
    tryOpenCaixa(doc);
    tryOpenThermalPrint(doc);
  }

  function restoreBaselineIfAvailable() {
    if (!pending || (pending.baseline || []).length) return;
    try {
      const raw = getTopDocument().defaultView.sessionStorage.getItem(BASELINE_KEY);
      const ids = JSON.parse(raw || '[]');
      if (Array.isArray(ids) && ids.length) {
        pending.baseline = ids.map(String);
        savePendingState();
      }
    } catch { }
  }

  function scan() {
    loadPendingState();
    loadPendingThermalPrint();
    restoreBaselineIfAvailable();

    if (pending) {
      retryConfirmedCaixa();
    } else {
      // Mantém a última listagem conhecida como referência para o próximo DAV.
      persistBaseline(snapshotExistingDavIds());
    }

    for (const doc of getFrameDocuments()) {
      attachDocument(doc);
      installCheckbox(doc);
      installThermalOption(doc);
      installPrintTypePreference(doc);
      installPendingCaixa(doc);
      tryOpenCaixa(doc);
      tryOpenThermalPrint(doc);
    }
  }

  scan();
  scanTimer = window.setInterval(scan, SCAN_INTERVAL_MS);
  window.addEventListener('pagehide', () => {
    if (scanTimer) window.clearInterval(scanTimer);
    stopThermalTitlePolling();
  }, { once: true });
})();