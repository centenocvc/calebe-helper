(() => {
  'use strict';

  // ⬛ Bloco: configuração e estado do módulo.
  const MODULE_ID = 'calebe-helper-emitir-nota';
  const CHECKBOX_ID = 'calebe-helper-emitir-nota-finalizar';
  const PENDING_KEY = 'calebeHelperEmitirNotaPendenteV1';
  const SCAN_INTERVAL_MS = 500;
  const WAIT_NEW_DAV_MS = 45000;

  let observedDocs = new WeakSet();
  let pending = null;
  let scanTimer = null;

  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
  const getTopDocument = () => {
    try { return window.top.document; } catch { return document; }
  };

  function getFrameDocuments() {
    const host = getTopDocument();
    const docs = [];
    const seen = new Set();

    const add = doc => {
      if (!doc?.documentElement || seen.has(doc)) return;
      seen.add(doc);
      docs.push(doc);
    };

    add(host);
    for (const frame of host.querySelectorAll('iframe')) {
      try { add(frame.contentDocument); } catch { }
    }
    return docs;
  }

  function isDavCreationPage(doc) {
    if (!doc?.documentElement) return false;
    const hasProductFields = Boolean(
      doc.getElementById('inlinePrdCodigo') &&
      (doc.getElementById('btnObs') || doc.getElementById('inlinePrdQtd'))
    );
    const path = String(doc.location?.pathname || '');
    return hasProductFields || (/\/dav0[12]\//i.test(path) &&
      Boolean(doc.querySelector('input[id*="cli"], input[name*="cli"]')));
  }

  function isDavListPage(doc) {
    if (!doc?.documentElement) return false;
    const heading = [...doc.querySelectorAll('h6')].some(el =>
      /DAV01[\s\S]{0,40}Documento Auxiliar de Venda/i.test(el.textContent || '')
    );
    return heading && Boolean(doc.querySelector('tr button[onclick*="duplicarDav("]'));
  }

  function extractDavId(row) {
    const formatted = normalize(row?.textContent).match(/\b\d{3}-(\d{5})\b/);
    if (formatted) return Number(formatted[1]) || null;
    const selected = String(row?.getAttribute?.('onclick') || '').match(/selecionarLinha\s*\(\s*this\s*,\s*(\d+)/);
    if (selected) return Number(selected[1]) || null;
    const duplicate = String(row?.querySelector('button[onclick*="duplicarDav("]')?.getAttribute('onclick') || '')
      .match(/duplicarDav\s*\(\s*(\d+)/);
    return duplicate ? Number(duplicate[1]) || null : null;
  }

  function collectDavIds(doc) {
    if (!isDavListPage(doc)) return [];
    return [...doc.querySelectorAll('tr')]
      .filter(row => row.querySelector('button[onclick*="duplicarDav("]'))
      .map(extractDavId)
      .filter(id => Number.isFinite(id) && id > 0);
  }

  function snapshotExistingDavIds() {
    const ids = new Set();
    for (const doc of getFrameDocuments()) {
      for (const id of collectDavIds(doc)) ids.add(String(id));
    }
    return [...ids];
  }

  function createCheckbox(doc, anchor) {
    const wrapper = doc.createElement('div');
    wrapper.className = 'form-check form-check-inline mb-0 me-2 ms-auto flex-shrink-0';
    wrapper.id = MODULE_ID;

    const input = doc.createElement('input');
    input.type = 'checkbox';
    input.className = 'form-check-input';
    input.id = CHECKBOX_ID;
    input.autocomplete = 'off';

    const label = doc.createElement('label');
    label.className = 'form-check-label';
    label.htmlFor = CHECKBOX_ID;
    label.textContent = 'Emitir nota ao finalizar';

    wrapper.append(input, label);
    anchor.insertAdjacentElement('beforebegin', wrapper);
    return input;
  }



  function installCheckbox(doc) {
    if (!isDavCreationPage(doc)) return;
    if (doc.getElementById(CHECKBOX_ID)) return;

    // ⬛ Bloco: localiza a linha principal do cabeçalho.
    const headerRow = doc.querySelector(
      '.d-flex.align-items-center.justify-content-between.mb-3.flex-wrap.gap-2'
    );

    if (!headerRow) return;

    // ⬛ Bloco: localiza o grupo de botões à direita.
    const actionGroup = [...headerRow.children].find(el =>
      el.matches('.d-flex.gap-2') &&
      el.querySelector(
        '#btnObs, #btnFecharDav, #btnDetalhes, #btnVoltar2'
      )
    );

    if (!actionGroup) return;

    // ⬛ Bloco: insere o checkbox imediatamente antes dos botões.
    const input = createCheckbox(doc, actionGroup);
    const STORAGE_KEY = 'calebeHelperEmitirNotaAutomaticamente';

    input.checked = localStorage.getItem(STORAGE_KEY) === 'true';
    input.setAttribute('aria-checked', String(input.checked));

    // ⬛ Bloco: salva cada alteração para os próximos DAVs.
    input.addEventListener('change', () => {
      localStorage.setItem(STORAGE_KEY, String(input.checked));
      input.setAttribute('aria-checked', String(input.checked));
    });
  }


  function isFinalizationControl(control) {
    if (!control) return false;
    if (control.id === 'btnNovoDav' || control.matches('.calebe-helper-caixa-dav')) return false;

    const label = normalize([
      control.textContent,
      control.value,
      control.title,
      control.getAttribute('aria-label'),
      control.getAttribute('onclick'),
      control.id,
      control.className
    ].join(' ')).toLowerCase();

    if (/adicionar|incluir item|novo item|produto|observa[cç][aã]o|limpar|cancelar|voltar/.test(label)) return false;
    return /finalizar|concluir|gravar dav|salvar dav|confirmar dav|fechar dav|emitir dav|salvar|gravar|confirmar/.test(label);
  }

  function savePendingState() {
    try {
      getTopDocument().defaultView.sessionStorage.setItem(PENDING_KEY, JSON.stringify(pending));
    } catch { }
  }

  function clearPendingState() {
    pending = null;
    try { getTopDocument().defaultView.sessionStorage.removeItem(PENDING_KEY); } catch { }
  }

  function loadPendingState() {
    if (pending) return;
    try {
      const raw = getTopDocument().defaultView.sessionStorage.getItem(PENDING_KEY);
      const data = JSON.parse(raw || 'null');
      if (data && data.createdAt && Date.now() - data.createdAt < WAIT_NEW_DAV_MS) pending = data;
      else if (raw) getTopDocument().defaultView.sessionStorage.removeItem(PENDING_KEY);
    } catch { }
  }

  function beginPendingEmit(doc, control) {
    const checkbox = doc.getElementById(CHECKBOX_ID);
    if (!checkbox?.checked || pending || !isFinalizationControl(control)) return;

    const baseline = snapshotExistingDavIds();
    pending = {
      createdAt: Date.now(),
      baseline,
      sourceUrl: String(doc.location?.href || ''),
      control: normalize(control.textContent || control.value || control.title)
    };
    savePendingState();
    console.info('[Calebe Helper] Emissão automática marcada; aguardando a confirmação do DAV salvo.');
  }

  function tryOpenCaixa(doc) {
    if (!pending || Date.now() - pending.createdAt > WAIT_NEW_DAV_MS) {
      if (pending) {
        console.warn('[Calebe Helper] Não foi possível localizar o novo DAV dentro do prazo; a Caixa DAV não foi aberta automaticamente.');
        clearPendingState();
      }
      return;
    }
    if (!isDavListPage(doc)) return;

    const baseline = new Set((pending.baseline || []).map(String));
    const candidates = [...doc.querySelectorAll('tr')]
      .map(row => ({ row, id: extractDavId(row), button: row.querySelector('button.calebe-helper-caixa-dav') }))
      .filter(item => item.id && !baseline.has(String(item.id)));

    // A dav1.js instala o botão Caixa DAV via MutationObserver. Aguarda até ele aparecer.
    const ready = candidates.find(item => item.button && !item.button.disabled);
    if (!ready) return;

    const id = ready.id;
    clearPendingState();
    console.info(`[Calebe Helper] DAV ${id} identificado; abrindo a mesma Caixa DAV do botão existente.`);
    ready.button.click();
  }

  function onDocumentClick(doc, event) {
    const target = event.target instanceof doc.defaultView.Element ? event.target : null;
    if (!target) return;
    const control = target.closest('button, a, input[type="button"], input[type="submit"]');
    if (!control) return;

    // Guarda a lista atual antes de abrir um DAV novo.
    if (control.id === 'btnNovoDav' || /novo dav/i.test(normalize(control.textContent || control.title))) {
      const ids = snapshotExistingDavIds();
      if (ids.length) {
        try {
          getTopDocument().defaultView.sessionStorage.setItem(
            `${PENDING_KEY}:baseline`,
            JSON.stringify(ids)
          );
        } catch { }
      }
      return;
    }

    if (!isDavCreationPage(doc)) return;
    beginPendingEmit(doc, control);
  }

  function attachDocument(doc) {
    if (!doc?.documentElement || observedDocs.has(doc)) return;
    observedDocs.add(doc);
    doc.addEventListener('click', event => onDocumentClick(doc, event), true);

    const observer = new MutationObserver(() => {
      installCheckbox(doc);
      tryOpenCaixa(doc);
    });
    observer.observe(doc.documentElement, { childList: true, subtree: true });

    installCheckbox(doc);
    tryOpenCaixa(doc);
  }

  function restoreBaselineIfAvailable() {
    if (!pending || (pending.baseline || []).length) return;
    try {
      const raw = getTopDocument().defaultView.sessionStorage.getItem(`${PENDING_KEY}:baseline`);
      const ids = JSON.parse(raw || '[]');
      if (Array.isArray(ids) && ids.length) {
        pending.baseline = ids.map(String);
        savePendingState();
      }
    } catch { }
  }

  function scan() {
    loadPendingState();
    restoreBaselineIfAvailable();
    for (const doc of getFrameDocuments()) {
      attachDocument(doc);
      installCheckbox(doc);
      tryOpenCaixa(doc);
    }
  }

  scan();
  scanTimer = window.setInterval(scan, SCAN_INTERVAL_MS);
  window.addEventListener('pagehide', () => {
    if (scanTimer) window.clearInterval(scanTimer);
  }, { once: true });
})();
