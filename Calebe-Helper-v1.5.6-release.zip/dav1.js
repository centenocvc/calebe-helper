(() => {
  'use strict';
  if (window.top !== window.self) return;

  let observedFrame = null;
  let observedDocument = null;
  let documentObserver = null;
  let pendingCaixaDavId = null;

  function isDavList(doc) {
    return [...doc.querySelectorAll('h6')].some(element =>
      /DAV01[\s\S]{0,40}Documento Auxiliar de Venda/i.test(element.textContent || '')
    );
  }

  function extractDavId(row) {
    const formatted = String(row?.textContent || '').match(/\b\d{3}-(\d{5})\b/);
    if (formatted) return Number(formatted[1]) || null;
    const selected = String(row?.getAttribute?.('onclick') || '').match(/selecionarLinha\s*\(\s*this\s*,\s*(\d+)/);
    return selected ? Number(selected[1]) || null : null;
  }

  function installCaixaButtons(doc) {
    if (!isDavList(doc)) return;
    for (const duplicateButton of doc.querySelectorAll('button[onclick*="duplicarDav("]')) {
      if (duplicateButton.parentElement?.querySelector('.calebe-helper-caixa-dav')) continue;
      const button = doc.createElement('button');
      button.type = 'button';
      button.className = 'ms-1 btn btn-success btn-sm calebe-helper-caixa-dav';
      button.title = 'Caixa DAV';
      button.innerHTML = '<i class="bi bi-cash-coin"></i>';
      button.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
        const row = duplicateButton.closest('tr');
        const davId = extractDavId(row);
        const link = doc.querySelector('a[href*="modulos/nfe001/nfe001.php"]');
        if (!davId || !link) {
          console.error('[Calebe Helper] DAV ou link do Emissor NF-e não encontrado.');
          return;
        }
        pendingCaixaDavId = davId;
        link.click();
      });
      duplicateButton.insertAdjacentElement('afterend', button);
    }
  }

  function openPendingCaixa(doc) {
    if (!pendingCaixaDavId || !/\/modulos\/nfe001\/nfe001\.php$/i.test(doc.location.pathname)) return;
    const mode = doc.getElementById('filtAcao');
    if (mode && mode.value !== 'emitir') {
      mode.value = 'emitir';
      mode.dispatchEvent(new doc.defaultView.Event('change', { bubbles: true }));
      return;
    }
    const nativeLink = [...doc.querySelectorAll('a[onclick*="abrirCaixaDav("]')].find(link => {
      const match = String(link.getAttribute('onclick') || '').match(/abrirCaixaDav\s*\(\s*(\d+)\s*,\s*1/);
      return match && Number(match[1]) === pendingCaixaDavId;
    });
    if (nativeLink) {
      pendingCaixaDavId = null;
      nativeLink.click();
    }
  }

  function install(doc) {
    if (!doc?.documentElement) return;
    installCaixaButtons(doc);
    openPendingCaixa(doc);
  }

  function observeFrame() {
    const frame = document.getElementById('mainIframe');
    if (frame && frame !== observedFrame) {
      observedFrame = frame;
      frame.addEventListener('load', observeFrame);
    }
    let doc;
    try { doc = frame?.contentDocument || null; } catch { doc = null; }
    if (!doc) return;
    if (doc !== observedDocument) {
      documentObserver?.disconnect();
      observedDocument = doc;
      if (!doc.documentElement) return;
      documentObserver = new MutationObserver(() => install(doc));
      documentObserver.observe(doc.documentElement, { childList: true, subtree: true });
    }
    install(doc);
  }

  observeFrame();
  new MutationObserver(observeFrame).observe(document.documentElement, { childList: true, subtree: true });
})();
