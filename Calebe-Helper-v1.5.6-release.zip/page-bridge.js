(() => {
  'use strict';
  if (document.__calebeHelperEmitirBridge) return;
  document.__calebeHelperEmitirBridge = true;

  const emit = (name, detail = {}) => {
    document.dispatchEvent(new CustomEvent(`calebe-helper:${name}`, { detail }));
  };

  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = async function (...args) {
      const response = await originalFetch.apply(this, args);
      const body = args[1]?.body;
      if (body instanceof FormData && body.get('acao') === 'fechar_dav') {
        try {
          const result = await response.clone().json();
          if (!result?.erro) {
            const davId = Number(new URLSearchParams(window.location.search).get('id')) || null;
            emit('dav-close-confirmed', { davId, ok: true });
          }
        } catch { }
      }
      return response;
    };
  }

  document.addEventListener('calebe-helper:command', event => {
    const detail = event.detail || {};
    try {
      if (detail.action === 'reserve-thermal-print-window') {
        const popup = window.open('about:blank', 'calebeHelperThermalPrint');
        if (!popup) throw new Error('O navegador bloqueou a janela reservada para a impressão térmica.');
        try {
          popup.document.title = 'Preparando impressão térmica...';
          popup.document.body.textContent = 'Aguardando a confirmação do fechamento do DAV.';
        } catch { }
        emit('thermal-window-reserved', { ok: true });
        return;
      }
      if (detail.action === 'print-thermal-dav') {
        const davId = Number(detail.davId);
        if (!Number.isInteger(davId) || davId <= 0) throw new Error('Número do DAV inválido.');
        if (typeof window.abrirEspelhoDavTermico !== 'function') {
          throw new Error('A função abrirEspelhoDavTermico não está disponível neste iframe.');
        }
        const originalOpen = window.open;
        try {
          window.open = function (url, target, features) {
            const requestedTarget = !target || target === '_blank'
              ? (detail.windowName || 'calebeHelperThermalPrint')
              : target;
            return originalOpen.call(window, url, requestedTarget, features);
          };
          window.abrirEspelhoDavTermico(davId);
        } finally {
          window.open = originalOpen;
        }
        emit('thermal-print-result', { id: detail.requestId, ok: true, davId });
      }
    } catch (error) {
      if (detail.action === 'print-thermal-dav') {
        emit('thermal-print-result', {
          id: detail.requestId,
          ok: false,
          error: String(error?.message || error)
        });
      }
      emit('command-result', { id: detail.id, ok: false, error: String(error?.message || error) });
    }
  });
})();
